/*
The Game Project 7.2 – make it awesome part 2
 */
var gameChar_x;
var gameChar_y;
var floorPos_y;
var isLeft;
var isRight;
let isFalling;
let isPlummeting;
var collectables;
var canyons;
var tree;
var cloud;
var cloudsScale;
var mountain;
var cameraPosX;
var game_score;
var flagpole;
var lives;
let cameraPosY;

var jumpSound;

var platforms = [];

var enemies;

function preload(){
	soundFormats('mp3', 'wav');

	//load sound
	jumpSound = loadSound('assets/jump.wav');
	jumpSound.setVolume(0.1);
	dieSound = loadSound('assets/die.mp3');
	dieSound.setVolume(0.1);
	winSound = loadSound('assets/win.mp3');
	winSound.setVolume(0.1);
}


function setup()
{
	createCanvas(1024, 576);
	floorPos_y = height * 3/4;
	gameChar_x = width/2;
	gameChar_y = floorPos_y;
	isLeft = false;
	isRight = false;
	isFalling = false;
	isPlummeting = false;

	//Move collectable and canyon with this code - code for specific collectable locations

	collectables = [{x_pos: 70 + random(0,10), y_pos: floorPos_y -50 , size: 50, isFound: false, isShakeingCount: 0}, 
		{x_pos: 300 + random(0,10), y_pos: floorPos_y -50 , size: 50, isFound: false, isShakeingCount: 0}, 
		{x_pos: 1200 + random(0,10), y_pos: floorPos_y -50 , size: 50, isFound: false, isShakeingCount: 0},
		{x_pos: 600 + random(0,10), y_pos: floorPos_y -50 , size: 50, isFound: false, isShakeingCount: 0},
		{x_pos: 600 + random(0,10), y_pos: floorPos_y -250 , size: 50, isFound: false, isShakeingCount: 0},
		{x_pos: 1100 + random(0,10), y_pos: -100 , size: 50, isFound: false, isShakeingCount: 0}];
	
	canyons = [{x_pos: 200, y_pos: floorPos_y, width: 70, canyonWaterYFalls: floorPos_y + 10}, 
		{x_pos: 400, y_pos: floorPos_y, width: 70, canyonWaterYFalls: floorPos_y + 10},
		{x_pos: 850, y_pos: floorPos_y, width: 150, canyonWaterYFalls: floorPos_y + 10},
		{x_pos: 2000, y_pos: floorPos_y, width: 1000, canyonWaterYFalls: floorPos_y + 10},
		{x_pos: -2000, y_pos: floorPos_y, width: 1000, canyonWaterYFalls: floorPos_y + 10}];

	//Add/subtract this array to change trees x location
	tree = {
		pos_x: [10, 300, 450, 900, 1150], 
		pos_y: (height/2 - 20) + 62,
		TrunkHeight: 130,
		radius: 40
	}

	//Add/subtract this array to change clouds x and y location
	cloud = {
		cloudX : [random(0,width), random(0,width), random(0,width), random(0,width), random(0,width)],
		cloudY : [random(20,180),random(20,180),random(20,180),random(20,180),random(20,180)],
		cloudSize : 30,
		cloudColour : fill(255, 255, 255, 0),
		cloudScale : [random(0.5,2),random(0.5,2),random(0.5,2),random(0.5,2),random(0.5,2)]

	}

	//Mountains
	mountain = {
		pos_x: [100, 350, 800],
		pos_y : floorPos_y
	}

	cameraPosX = 0;

	game_score = 0;
	flagpole ={
		x_pos: 1800,
		isReached: false
	}
	lives =3;

	//draw idividual platforns
	var platformsarr;
	platformsarr = [{x: 350, y: 340, l:200},
		{x: 550, y: 240, l:200},
		{x: 1050, y: 340, l:200},
		{x: 1050, y: 240, l:200},
		{x: 1050, y: 140, l:200},
		{x: 1050, y: 40, l:200},];

	for(var i = 0; i < platformsarr.length; i++){
		platforms.push(new Platforms(platformsarr[i].x, platformsarr[i].y, platformsarr[i].l));
	}

	enemies = [];
	enemies.push(new Enemy(1, floorPos_y - 20, 100))
	enemies.push(new Enemy(1750, floorPos_y - 20, 100))

	
}

function draw()
{
	///////////DRAWING CODE//////////
	if (gameChar_y > height + 500){
		background(255, 0,0 );
	}
	else{
		background(100,155,255); //fill the sky blue
	}
	
	noStroke();

	//Code for side scrolling
	push()
	
	const newCameraPosY = gameChar_y - width / 2;
	cameraPosY = gameChar_y - floorPos_y;
	cameraPosY = cameraPosY * 0.945 + newCameraPosY * 0.055;
	translate(-cameraPosX, -cameraPosY);
	
	fill(0,155,0);
	rect(-1000, floorPos_y, +3000, height - floorPos_y); //draw some green ground
	fill(255, 0, 0);
	rect(-2000, height, + 4800, 800);
	//translate(-cameraPosX, 0);

	//Clouds
	for(var i = 0; i <= cloud.cloudX.length ; i++){
		drawClouds(i);
	}

	//Mountain
	drawMountains()

	// Draw the trees
	drawTrees();

	//draw the canyon (my waterfall)
	for(var i = 0; i < canyons.length; i ++){
		checkCanyon(canyons[i]);
	}

	//draw collectable
	for(var i = 0; i < collectables.length; i ++){
		
		if(!collectables[i].isFound){
			checkCollectable(collectables[i]);	
			drawCollectable(collectables[i]);	
			
		}
	}

	// Draw flagpole
	renderFlagpole()

	// Draw Character
	drawCharacter();

	// Draw Platforms
	platforms.forEach(p => p.drawPlatform());

	for(var i =0; i < enemies.length; i++){
		enemies[i].draw();
		var isContact = enemies[i].checkContact(gameChar_x, gameChar_y);
		if (isContact){
			if(lives > 0){
				startGame();
				break;

			}
		}
	}

	pop()

	textAlign(LEFT);
	fill(0);
	stroke(5);
	textSize(30);
	text("Score: " + game_score, 20, 40);

	if(flagpole.isReached == false){
		checkFlagpole();
	}

	for (var i = 0; i < lives; i++){
		fill(255,0,0);
		heart(800 + (i * 30),20,30);
	}
	checkPlayerDie();

	if(lives < 1){
		fill(0);
		stroke(5);
		textSize(80);
		textAlign(CENTER);
		text("Game over", width/2, height/2 - 80);
		text("Press space to continue", width/2, height/2+ 80);
		
		if(key == ' '){
			setup();
		}
	}

	if(flagpole.isReached == true){
		fill(0);
		stroke(5);
		textSize(80);
		textAlign(CENTER);
		text("Level complete", width/2, height/2 - 80);
		text("Press space to continue", width/2, height/2+ 80);
		//winSound.play();
		if(key == ' '){
			setup();
		}
	}

	///////////INTERACTION CODE//////////
	//Put conditional statements to move the game character below here
	interaction();
}


function interaction(){
	if (isLeft == true){
		gameChar_x -=3;
		cameraPosX -=3;
	}
	if (isRight){
		gameChar_x +=3;
		cameraPosX +=3;
	}

	isFalling =false
	if(gameChar_y < floorPos_y){
		isFalling = true;
		for(let i = 0; i < platforms.length; i++){
			if(platforms[i].contact()){
				isFalling = false;
				break;
			}
			
		}
		if(isFalling){
			if (gameChar_y > height + 500){
				//
			}
			else{
				gameChar_y += 3;
			}
			
		}
	}

	if (isPlummeting){
		if(gameChar_y > height + 500){
			//
		}
		else{
			gameChar_y += 3;
		}
		
		isLeft = false;
		isRight = false;
	}
	else{
		isPlummeting = false;
	}
}

function keyPressed()
{
	// if statements to control the animation of the character when
	// keys are pressed.
		
	if (key == "d" && isPlummeting == false){
		isRight = true;
	}
	if (key == "a" && isPlummeting == false){
		isLeft = true;
	}
	if (key == "w" && isPlummeting == false){
		if (isFalling){
			//
		}
		else{
			gameChar_y -= 130;
			jumpSound.play();
		}
	}
}

function keyReleased()
{
	// if statements to control the animation of the character when
	// keys are released.
	if (key == "d"){
		isRight = false;
	}
	if (key == "a"){
		isLeft = false;
	}
}


function drawClouds(i){
	fill(255, 255, 255, 220)
	ellipse(cloud.cloudX[i],cloud.cloudY[i] ,cloud.cloudSize * cloud.cloudScale[i])
	ellipse(cloud.cloudX[i] +((cloud.cloudSize/1.5)*cloud.cloudScale[i]),cloud.cloudY[i] ,(cloud.cloudSize*1.2)*cloud.cloudScale[i])
	ellipse(cloud.cloudX[i] +((cloud.cloudSize*1.5)*cloud.cloudScale[i]),cloud.cloudY[i] ,(cloud.cloudSize*1.5)*cloud.cloudScale[i])		
	if(cloud.cloudX[i] > gameChar_x + 700){
		cloud.cloudX[i] =  random(gameChar_x-700 ,gameChar_x-1000);
	}
	if(cloud.cloudX[i] < gameChar_x + 700){
		cloud.cloudX[i] += 4;
	}
}

function drawMountains(){
	for(var i = 0; i < mountain.pos_x.length; i++)
	{
		fill(90);
		triangle(mountain.pos_x[i] , mountain.pos_y ,mountain.pos_x[i] + 100, mountain.pos_y - 200 ,mountain.pos_x[i] + 200,mountain.pos_y);
		triangle(mountain.pos_x[i] - 50, mountain.pos_y ,mountain.pos_x[i] + 50 ,mountain.pos_y - 150 ,mountain.pos_x[i] + 150, mountain.pos_y);
	}
}

function drawTrees(){
	for(var i = 0; i < tree.pos_x.length; i++){
		noStroke();
		fill(139,69,19);
		rect(tree.pos_x[i], tree.pos_y, tree.radius, tree.TrunkHeight - 25, 2)
		fill(0,255,0);
		fill(0,255,0);
		triangle(tree.pos_x[i] - 40, tree.pos_y, tree.pos_x[i] + 80, tree.pos_y, tree.pos_x[i] + 20, tree.pos_y -50)
		triangle(tree.pos_x[i] - 45, tree.pos_y + 10, tree.pos_x[i] + 85, tree.pos_y + 10, tree.pos_x[i] + 20, tree.pos_y - 40)

		fill(139,69,19);
		rect(tree.pos_x[i] + 50, tree.pos_y + 20, tree.radius, tree.TrunkHeight - 44, 2)
		fill(0,255,0);
		triangle(tree.pos_x[i] + 10, tree.pos_y + 20, tree.pos_x[i] + 125, tree.pos_y + 20, tree.pos_x[i] + 70, tree.pos_y - 30)
		triangle(tree.pos_x[i] + 5, tree.pos_y + 30, tree.pos_x[i] + 130, tree.pos_y + 30, tree.pos_x[i] + 70, tree.pos_y - 20)
	
	}
}

function checkCollectable(t_collectable){
	if (dist(gameChar_x, gameChar_y, t_collectable.x_pos, t_collectable.y_pos + 50 ) <= 30){
		t_collectable.isFound = true;
	}
	if(t_collectable.isFound == true){
		fill(0);
		game_score += 1;
	}
}

function drawCollectable(t_collectable){
	if(t_collectable.isFound == false){
		fill(255, 255, 0);
		noStroke();
		beginShape();
		if (t_collectable.isShakeingCount <=20){
			t_collectable.shakeCollectableX = random(0,3);
			t_collectable.isShakeingCount +=1;
		}
		if (t_collectable.isShakeingCount > 20){
			t_collectable.isShakeingCount = 0;
		}		
		vertex(t_collectable.x_pos + t_collectable.shakeCollectableX , t_collectable.y_pos - 30);// 100 = 450
		vertex(t_collectable.x_pos - 20 + t_collectable.shakeCollectableX, t_collectable.y_pos);
		vertex(t_collectable.x_pos + t_collectable.shakeCollectableX, t_collectable.y_pos + 40);
		vertex(t_collectable.x_pos + 20 + t_collectable.shakeCollectableX, t_collectable.y_pos);
		endShape();
	}
}

function checkCanyon(t_canyon){
	
	fill(60, 60, 255);
	noStroke();
	rect(t_canyon.x_pos, t_canyon.y_pos , t_canyon.width, height - t_canyon.y_pos)
	stroke(255);
	canyonWaterX = t_canyon.x_pos + 10, t_canyon.x_pos + t_canyon.width - 20;	
	if(t_canyon.canyonWaterYFalls < height){
		t_canyon.canyonWaterYFalls = t_canyon.canyonWaterYFalls + 3;
	}
	if(t_canyon.canyonWaterYFalls > height - 10){
		t_canyon.canyonWaterYFalls = t_canyon.y_pos+ 10;
	}
	for (var i = 0; i < (t_canyon.width/10)-1; i++){
		line(canyonWaterX,t_canyon.y_pos+ 10,canyonWaterX, t_canyon.canyonWaterYFalls);
		canyonWaterX += 10;
	}

	if(gameChar_x > t_canyon.x_pos && gameChar_x < t_canyon.x_pos + t_canyon.width && gameChar_y >= floorPos_y ){
		isPlummeting = true;
		
	}
}



function renderFlagpole(){
	push()
	strokeWeight(10);
	stroke(180);
	line(flagpole.x_pos, floorPos_y, flagpole.x_pos, floorPos_y - 250);
	pop()
	noStroke()

	if (!flagpole.isReached){
		fill(255,0,0);
		rect(flagpole.x_pos + 10, floorPos_y - 250, 100, 50);
		fill(255,255,0);
		ellipse(flagpole.x_pos + 60, floorPos_y - 225, 50);	
	}
	if(flagpole.isReached){
		fill(255,0,0);
		rect(flagpole.x_pos + 10, floorPos_y - 50, 100, 50);
		fill(255,255,0);
		ellipse(flagpole.x_pos + 60, floorPos_y - 25, 50);	
	}
}

function checkFlagpole(){
	var d = abs(gameChar_x - flagpole.x_pos)
	if(d < 15){
		flagpole.isReached = true;
	}
	else{
		flagpole.isReached = false;
	}

}

function checkPlayerDie(){
	if(gameChar_y > height + 100){
		lives -= 1;
		if(lives > 0){
			startGame();
		}
	
	}


}

function startGame(){
	gameChar_x = width/2;
	gameChar_y = floorPos_y;
	isLeft = false;
	isRight = false;
	isFalling = false;
	isPlummeting = false;
	shakeCollectableX = random(0,10);

	//Move collectable and canyon with this code
	collectables = [{x_pos: 70 + shakeCollectableX, y_pos: floorPos_y -50 , size: 50, isFound: false, isShakeingCount: 0}, 
		{x_pos: 300 + shakeCollectableX, y_pos: floorPos_y -50 , size: 50, isFound: false, isShakeingCount: 0}, 
		{x_pos: 1200 + shakeCollectableX, y_pos: floorPos_y -50 , size: 50, isFound: false, isShakeingCount: 0},
		{x_pos: 600 + shakeCollectableX, y_pos: floorPos_y -50 , size: 50, isFound: false, isShakeingCount: 0}];
	
	canyons = [{x_pos: 200, y_pos: floorPos_y, width: 70, canyonWaterYFalls: floorPos_y + 10}, 
		{x_pos: 400, y_pos: floorPos_y, width: 70, canyonWaterYFalls: floorPos_y + 10},
		{x_pos: 850, y_pos: floorPos_y, width: 150, canyonWaterYFalls: floorPos_y + 10},
		{x_pos: 2000, y_pos: floorPos_y, width: 1000, canyonWaterYFalls: floorPos_y + 10},
		{x_pos: -2000, y_pos: floorPos_y, width: 1000, canyonWaterYFalls: floorPos_y + 10}];

	//Add/subtract this array to change trees x location
	trees_x = [10, 300, 450, 900, 1150];

	tree = {
		pos_x: trees_x , 
		pos_y: (height/2 - 20) + 62,
		TrunkHeight: 130,
		radius: 40
	}

	//Add/subtract this array to change clouds x and y location
	clouds = [random(0,width), random(0,width), random(0,width), random(0,width), random(0,width)];
	var clouds_Y = [random(20,180),random(20,180),random(20,180),random(20,180),random(20,180)];
	cloudsScale = [random(0.5,2),random(0.5,2),random(0.5,2),random(0.5,2),random(0.5,2)];
	cloud = {
		cloudX : clouds,
		cloudY : clouds_Y,
		cloudSize : 30,
		cloudColour : fill(255, 255, 255, 100),
		cloudScale : cloudsScale

	}

	//Mountains
	mountains = [100, 350, 800];
	mountain = {
		pos_x: mountains,
		pos_y : floorPos_y
	}
	
	cameraPosX = 0;

	game_score = 0;
	flagpole ={
		x_pos: 1800,
		isReached: false
	}
	
	var platformsarr;
	platformsarr = [{x: 350, y: 340, l:200},
		{x: 550, y: 240, l:200},
		{x: 1050, y: 340, l:200},
		{x: 1050, y: 240, l:200},
		{x: 1050, y: 140, l:200},
		{x: 1050, y: 40, l:200},];

	for(var i = 0; i < platformsarr.length; i++){
		platforms.push(new Platforms(platformsarr[i].x, platformsarr[i].y, platformsarr[i].l));
	}

}

// Heart function found https://editor.p5js.org/Mithru/sketches/Hk1N1mMQg

function heart(x, y, size) {
	beginShape();
	vertex(x, y);
	bezierVertex(x - size / 2, y - size / 2, x - size, y + size / 3, x, y + size);
	bezierVertex(x + size, y + size / 3, x + size / 2, y - size / 2, x, y);
	endShape(CLOSE);
  }

  function drawCharacter(){
	if(isLeft && isFalling)
	{
		// add your jumping-left code
		stroke(0);
		fill(200,100,150);
		ellipse(gameChar_x,gameChar_y - 55,34,34);
		fill(255);
		ellipse(gameChar_x - 12,gameChar_y -57, 6, 8);
		fill(0);
		ellipse(gameChar_x - 12,gameChar_y -57, 1, 1);
		fill(255,0,0);
		rect(gameChar_x -10,gameChar_y - 38, 20, 35);	
		fill(0);
		rect(gameChar_x + 5,gameChar_y-5,10,10);	
		fill(0);
		rect(gameChar_x -7,gameChar_y-5,10,10);	
		fill(180,0,0);	
		rect(gameChar_x -7, gameChar_y - 35 - 20, 7, 22);

	}

	else if(isRight && isFalling)
	{
		// add your jumping-right code
		stroke(0);
		fill(200,100,150);
		ellipse(gameChar_x,gameChar_y - 55,34,34);
		fill(255);
		ellipse(gameChar_x + 12,gameChar_y -57, 6, 8);
		fill(0);
		ellipse(gameChar_x + 12,gameChar_y -57, 1, 1);
		fill(255,0,0);
		rect(gameChar_x -10,gameChar_y - 38, 20, 35);	
		fill(0);
		rect(gameChar_x -15,gameChar_y-5,10,10);	
		fill(0);
		rect(gameChar_x -3,gameChar_y-5,10,10);	
		fill(180,0,0);
		rect(gameChar_x , gameChar_y - 35 - 20, 7, 22);

	}	
	else if(isLeft)
	{
		// add your walking left code
		stroke(0);
		fill(200,100,150);
		ellipse(gameChar_x,gameChar_y - 55,34,34);
		fill(255);
		ellipse(gameChar_x - 12,gameChar_y -57, 6, 8);
		fill(0);
		ellipse(gameChar_x - 12,gameChar_y -57, 1, 1);
		fill(255,0,0);
		rect(gameChar_x -10,gameChar_y - 38, 20, 35);	
		fill(0);
		rect(gameChar_x -2,gameChar_y-5,10,10);
		fill(0);
		rect(gameChar_x -7,gameChar_y-5,10,10);	
		fill(180,0,0);	
		rect(gameChar_x -7, gameChar_y - 15 - 20, 7, 22);
	}
	else if(isRight)
	{
		// add your walking right code
		stroke(0);
		fill(200,100,150);
		ellipse(gameChar_x,gameChar_y - 55,34,34);
		fill(255);
		ellipse(gameChar_x + 12,gameChar_y -57, 6, 8);
		fill(0);
		ellipse(gameChar_x + 12,gameChar_y -57, 1, 1);
		fill(255,0,0);
		rect(gameChar_x -10,gameChar_y - 38, 20, 35);	
		fill(0);
		rect(gameChar_x -8,gameChar_y-5,10,10);	
		fill(0);
		rect(gameChar_x -3,gameChar_y-5,10,10);	
		fill(180,0,0);
		rect(gameChar_x , gameChar_y - 15 - 20, 7, 22);
	}
	else if(isFalling || isPlummeting)
	{
		// add your jumping facing forwards code
		stroke(0);
		fill(200,100,150);
		ellipse(gameChar_x,gameChar_y - 55,34,34);
		fill(255);
		ellipse(gameChar_x - 8,gameChar_y -57, 8, 8);
		ellipse(gameChar_x + 8,gameChar_y -57, 8, 8);
		fill(0);
		ellipse(gameChar_x - 8,gameChar_y -57, 1, 1);
		ellipse(gameChar_x + 8,gameChar_y -57, 1, 1);
		fill(255,0,0);
		rect(gameChar_x -13,gameChar_y - 38, 26, 35);	
		fill(0);
		rect(gameChar_x -15,gameChar_y-5,10,10);	
		fill(0);
		rect(gameChar_x + 5,gameChar_y-5,10,10);	
		fill(180,0,0);
		rect(gameChar_x -20, gameChar_y - 35 - 20, 7, 22);
		rect(gameChar_x +13, gameChar_y - 35 - 20, 7, 22);

	}
	else
	{
		// add your standing front facing code
		stroke(0);
		fill(200,100,150);
		ellipse(gameChar_x,gameChar_y - 55,34,34);
		fill(255);
		ellipse(gameChar_x - 8,gameChar_y -57, 8, 8);
		ellipse(gameChar_x + 8,gameChar_y -57, 8, 8);
		fill(0);
		ellipse(gameChar_x - 8,gameChar_y -57, 1, 1);
		ellipse(gameChar_x + 8,gameChar_y -57, 1, 1);
		fill(255,0,0);
		rect(gameChar_x -13,gameChar_y - 38, 26, 35);	
		fill(0);
		rect(gameChar_x -15,gameChar_y-5,10,10);
		fill(0);
		rect(gameChar_x + 5,gameChar_y-5,10,10);	
		fill(180,0,0);
		rect(gameChar_x -20, gameChar_y - 35, 7, 22);
		rect(gameChar_x +13, gameChar_y - 35, 7, 22);


	}
  }

  

function Platforms(x, y, l){
	this.x = x;
	this.y = y;
	this.length = l;

	this.drawPlatform = function(){
		push();
		fill(0,155,0);
		rect(this.x, this.y, this.length, 15);
		pop();
	}

	this.contact = function(){
		if(isFalling){
			if(gameChar_x + 10 > this.x && gameChar_x - 10 < this.x + this.length &&
				gameChar_y + 6 > this.y && gameChar_y < this.y ){
					return true;
				}
		}
		else{
			return false;
		}
		
	}
	
}

function Enemy(x, y, range)
{
	this.x = x; 
	this.y = y;
	this.range = range;

	this.currentX = x;
	this.inc = 1;


	this.update = function(){
		this.currentX += this.inc;

		if(this.currentX >= this.x + this.range){
			this.inc = -1;
		}
		else if(this.currentX < this.x){
			this.inc = 1;
		}

	}
	this.draw = function()
	{
		this.update();
		fill(255, 0, 0);
		ellipse(this.currentX, this.y, 20, 20);
	}

	this.checkContact = function(gameChar_x, gameChar_y)
	{
		var d = dist(gameChar_x, gameChar_y, this.currentX, this.y);
		
		if(d < 25){
			return true;
		}
		return false;
	}

}